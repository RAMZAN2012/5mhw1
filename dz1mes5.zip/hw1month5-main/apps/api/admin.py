from django.contrib import admin
from apps.api.models import Task
# Register your models here.
admin.site.register(Task)